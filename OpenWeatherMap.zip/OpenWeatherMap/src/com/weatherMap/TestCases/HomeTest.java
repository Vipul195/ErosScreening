package com.weatherMap.TestCases;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.weatherMap.Utilities.ExcelReadingUtility;
import com.weatherMap.pages.HomePage;


public class HomeTest {
	
	public void check(String userName) throws IOException
	{
		if(ExcelReadingUtility.isTestRunable("HomeTest"))
		{
			HomePage hp = new HomePage();	
			hp.doCheck(userName);
			}
		}
	
	}


