package com.weatherMap.Utilities;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReadingUtility {
	
	public static boolean isTestRunable(String TCName) throws IOException
	{
		FileInputStream ip = new FileInputStream("F:\\Java Class\\workspace\\OpenWeatherMap\\src\\com\\weatherMap\\Data\\TestCaseRunStatus.xlsx");
		XSSFWorkbook wb = new XSSFWorkbook(ip); //XML Spreadsheet format //Horrible SpreadSheet Format
		XSSFSheet sh = wb.getSheet("TestCases");
		//total no of rows
		int totalRows=sh.getPhysicalNumberOfRows();
		
		//total no of columns
		int totalColumns=sh.getRow(0).getPhysicalNumberOfCells();
		
		for(int i=1;i<totalRows;i++)
		{
			if(sh.getRow(i).getCell(0).getStringCellValue().equalsIgnoreCase(TCName))
			{
				if(sh.getRow(i).getCell(1).getStringCellValue().equalsIgnoreCase("Y"))
				{
					return true;
				}
			}
		}
		return false;
	}
	
	public static Object[][] readLoginCases(String TCName) throws IOException
	{
		FileInputStream ip = new FileInputStream("F:\\Java Class\\workspace\\OpenWeatherMap\\src\\com\\weatherMap\\Data\\TestCaseRunStatus.xlsx");
		XSSFWorkbook wb = new XSSFWorkbook(ip); //XML Spreadsheet format //Horrible SpreadSheet Format
		XSSFSheet sh = wb.getSheet("LoginCase");
		
		//total no of rows
				int totalRows=sh.getPhysicalNumberOfRows();
				
				//total no of columns
				int totalColumns=sh.getRow(0).getPhysicalNumberOfCells();
				
				//2D Object array
				Object arr[][] = new Object[totalRows][totalColumns];
				
				for (int i=0;i<totalRows;i++)
				{
					for(int j=0;j<totalColumns;j++)
					{
						arr[i][j]= sh.getRow(i).getCell(j).getStringCellValue();
					}
				}
				return arr;
	}

}
