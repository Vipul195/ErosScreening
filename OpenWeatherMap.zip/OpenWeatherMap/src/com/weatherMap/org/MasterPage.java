package com.weatherMap.org;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;

public class MasterPage {
	
	public static WebDriver driver;
	public Properties prop;
	
	public MasterPage() throws IOException
	{
		FileInputStream ip = new FileInputStream("F:\\Java Class\\workspace\\OpenWeatherMap\\src\\com\\weatherMap\\OR\\Locators.properties");
		prop = new Properties();
		prop.load(ip);
	    if(prop.getProperty("browser").equalsIgnoreCase("Chrome"))
	{
	   
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\src\\com\\weatherMap\\thirdPartyDriver\\chromedriver.exe");
		driver = new ChromeDriver();
		 ChromeOptions  option = new ChromeOptions();
			option.addArguments("--disable-notifications");	
		driver = new ChromeDriver(option);
	}
	else
	{
		driver = new FirefoxDriver();
	}
	
	// Open MapWeather website
	driver.get("https://openweathermap.org/");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}
	
	public void sendKeys(String xpathKeys, String userData)
	{
		driver.findElement(By.xpath(prop.getProperty(xpathKeys))).sendKeys(userData);
	}
	public void elementDisplayed(String xpathkeys)
	{
		driver.findElement(By.xpath(prop.getProperty(xpathkeys))).isDisplayed();
	}
	
	public void click(String xpathkeys)
	{
		driver.findElement(By.xpath(prop.getProperty(xpathkeys))).click();
	}

}
