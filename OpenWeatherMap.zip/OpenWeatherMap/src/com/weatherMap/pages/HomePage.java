package com.weatherMap.pages;

import java.io.IOException;

import com.weatherMap.org.MasterPage;

public class HomePage extends MasterPage{

	public HomePage() throws IOException 
	{
	super();
	}
	
	public Boolean doCheck(String uName)
	{
		// Check website Logo is available
		elementDisplayed("WebsiteLogo_img");
		elementDisplayed("SignIn_Lnk");
		elementDisplayed("SignUp_Lnk");
				
		return true;
		
	}

}
